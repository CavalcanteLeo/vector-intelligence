import * as THREE from "three";

export function configureMaterials(model: THREE.Object3D) {
  model.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    if (object.name === "GlassDome") {
      object.material = new THREE.MeshPhysicalMaterial({
        color: 0xffffff, metalness: 0, roughness: 0.035,
        transmission: 1, thickness: 0.025, ior: 1.45,
        clearcoat: 1, clearcoatRoughness: 0.03,
        side: THREE.FrontSide, envMapIntensity: 0.4,
      });
      return;
    }
    if (object.name === "FaceShell" || object.name === "RobotVolumeBody") {
      const material = object.material as THREE.MeshStandardMaterial;
      material.roughness = 0.46;
      material.metalness = 0.12;
      const colors = object.geometry.getAttribute("color");
      const positions = object.geometry.getAttribute("position");
      if (colors) for (let i = 0; i < colors.count; i++) {
        const y = positions.getY(i);
        if (object.name === "RobotVolumeBody") {
          const neck = (1 - THREE.MathUtils.smoothstep(Math.abs(positions.getX(i)), 0.29, 0.42)) * THREE.MathUtils.smoothstep(y, -0.8, -0.69);
          colors.setXYZ(i, 0.78 * (1 - neck) + 0.012 * neck, 0.82 * (1 - neck) + 0.018 * neck, 0.9 * (1 - neck) + 0.03 * neck);
        }
        if (object.name === "FaceShell" && y > 0.18) colors.setXYZ(i, 0.78, 0.82, 0.9);
        if ((object.name === "FaceShell" && y < -0.48)) {
          colors.setXYZ(i, 0.012, 0.018, 0.03);
        }
      }
      if (colors) colors.needsUpdate = true;
    }
    if (!object.name.startsWith("SourceFaceDetail")) return;
    const original = object.material as THREE.MeshStandardMaterial;
    const positions = object.geometry.getAttribute("position");
    const colors = new Float32Array(positions.count * 4);
    for (let i = 0; i < positions.count; i++) {
      colors[i * 4] = colors[i * 4 + 1] = colors[i * 4 + 2] = 1;
      const front = THREE.MathUtils.smoothstep(positions.getZ(i), 0.38, 0.6);
      const face = 1 - THREE.MathUtils.smoothstep(Math.abs(positions.getX(i)), 0.48, 0.63);
      const neck = THREE.MathUtils.smoothstep(positions.getY(i), -0.48, -0.39);
      const top = 1 - THREE.MathUtils.smoothstep(positions.getY(i), 0.13, 0.24);
      colors[i * 4 + 3] = front * face * neck * top;
    }
    object.geometry.setAttribute("color", new THREE.BufferAttribute(colors, 4));
    object.material = new THREE.MeshBasicMaterial({
      map: original.map, transparent: true, vertexColors: true,
      depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
    });
  });
}

export function createNeckJoint(model: THREE.Object3D) {
  const body = model.getObjectByName("BodyRig");
  const head = model.getObjectByName("HeadRig");
  if (!body || !head) return;
  const graphite = new THREE.MeshStandardMaterial({ color: 0x101923, metalness: 0.7, roughness: 0.3 });
  const joint = new THREE.Mesh(new THREE.SphereGeometry(0.265, 48, 32), graphite);
  joint.scale.y = 0.5;
  joint.position.y = -0.62;
  body.add(joint);
  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.09, 64), graphite);
  collar.position.y = -0.69;
  body.add(collar);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.009, 12, 96),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(0.05, 1.2, 2.5), toneMapped: false }));
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.02;
  head.add(ring);
}
