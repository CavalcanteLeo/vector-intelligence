import * as THREE from "three";
import { addBrainHemispheres, brainPoint } from "./brain-shape";

type Edge = { a: number; b: number; curve: THREE.CatmullRomCurve3; length: number };

export function createNeuralNetwork(parent: THREE.Object3D) {
  const group = new THREE.Group();
  group.position.y = 0.62;
  parent.add(group);
  let seed = 19;
  const random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const nodes: THREE.Vector3[] = [];
  addBrainHemispheres(group);
  while (nodes.length < 360) {
    const theta = random() * Math.PI * 2;
    const phi = Math.acos(random() * 2 - 1);
    nodes.push(brainPoint(nodes.length % 2 ? -1 : 1, theta, phi, 1.025));
  }
  const edges: Edge[] = [];
  const adjacency: number[][] = nodes.map(() => []);
  const used = new Set<string>();
  const vertices: number[] = [];
  nodes.forEach((node, a) => {
    const nearest = nodes.map((point, b) => ({ b, distance: node.distanceToSquared(point) }))
      .filter(({ b }) => b !== a).sort((one, two) => one.distance - two.distance).slice(0, 5);
    nearest.forEach(({ b }) => {
      const key = [Math.min(a, b), Math.max(a, b)].join(":");
      if (used.has(key)) return;
      used.add(key);
      const middle = node.clone().lerp(nodes[b], 0.5);
      middle.y += 0.025;
      const curve = new THREE.CatmullRomCurve3([node, middle, nodes[b]]);
      const index = edges.length;
      edges.push({ a, b, curve, length: curve.getLength() });
      adjacency[a].push(index); adjacency[b].push(index);
      const points = curve.getPoints(8);
      for (let i = 0; i < points.length - 1; i++) vertices.push(...points[i].toArray(), ...points[i + 1].toArray());
    });
  });
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  const wires = new THREE.LineSegments(geometry, new THREE.LineBasicMaterial({ color: 0x0da7e0 }));
  group.add(wires);

  const particleGeometry = new THREE.SphereGeometry(0.006, 8, 6);
  const particleMaterial = new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 8, 12), toneMapped: false });
  const particles = new THREE.InstancedMesh(particleGeometry, particleMaterial, 500);
  particles.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  group.add(particles);
  const signals = Array.from({ length: 100 }, () => ({ edge: Math.floor(random() * edges.length), progress: random(), forward: random() > 0.5 }));
  const transform = new THREE.Object3D();
  const light = new THREE.PointLight(0x159aff, 1.2, 2, 2);
  group.add(light);
  return {
    update(delta: number) {
      signals.forEach((signal, index) => {
        let edge = edges[signal.edge];
        signal.progress += delta * 0.22 / edge.length;
        if (signal.progress >= 1) {
          const destination = signal.forward ? edge.b : edge.a;
          const options = adjacency[destination].filter((id) => id !== signal.edge);
          signal.edge = options[Math.floor(random() * options.length)] ?? signal.edge;
          edge = edges[signal.edge];
          signal.forward = edge.a === destination;
          signal.progress = 0;
        }
        for (let tail = 0; tail < 5; tail++) {
          const progress = Math.max(0, signal.progress - tail * 0.012 / edge.length);
          edge.curve.getPointAt(signal.forward ? progress : 1 - progress, transform.position);
          transform.scale.setScalar(1 - tail * 0.15);
          transform.updateMatrix();
          particles.setMatrixAt(index * 5 + tail, transform.matrix);
          if (index === 0 && tail === 0) light.position.copy(transform.position);
        }
      });
      particles.instanceMatrix.needsUpdate = true;
    },
  };
}
