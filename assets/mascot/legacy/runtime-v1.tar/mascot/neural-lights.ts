import * as THREE from "three";

function glowTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 128;
  const context = canvas.getContext("2d");
  if (!context) return null;
  const gradient = context.createRadialGradient(64, 64, 2, 64, 64, 64);
  gradient.addColorStop(0, "rgba(232,255,255,1)");
  gradient.addColorStop(0.13, "rgba(74,221,255,.9)");
  gradient.addColorStop(0.45, "rgba(0,117,255,.3)");
  gradient.addColorStop(1, "rgba(0,117,255,0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createNeuralLights(model: THREE.Object3D) {
  const texture = glowTexture();
  const branches: THREE.Mesh[] = [];
  const nodes: { mesh: THREE.Mesh; halo: THREE.Sprite; phase: number }[] = [];

  model.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    if (object.name.startsWith("BrainBranch") || object.name.startsWith("BrainCore")) {
      const material = (object.material as THREE.MeshStandardMaterial).clone();
      material.emissive = new THREE.Color(object.name.startsWith("BrainCore") ? 0x8aeaff : 0x008dff);
      material.emissiveIntensity = 3;
      object.material = material;
      branches.push(object);
    }
    if (!texture || !object.name.startsWith("BrainNode")) return;
    const material = (object.material as THREE.MeshStandardMaterial).clone();
    material.emissive = new THREE.Color(0x8cefff);
    material.emissiveIntensity = 5;
    object.material = material;
    object.geometry.computeBoundingSphere();
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: texture, color: 0x6bdcff, transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false,
    }));
    halo.position.copy(object.geometry.boundingSphere?.center ?? new THREE.Vector3());
    halo.scale.setScalar(0.18);
    object.add(halo);
    nodes.push({ mesh: object, halo, phase: nodes.length * 0.85 });
  });

  return {
    update(time: number) {
      for (let index = 0; index < branches.length; index++) {
        const material = branches[index].material as THREE.MeshStandardMaterial;
        material.emissiveIntensity = 2.2 + 2.2 * Math.max(0, Math.sin(time * 2.5 - index * 0.7));
      }
      for (const { mesh, halo, phase } of nodes) {
        const pulse = Math.pow(Math.max(0, Math.sin(time * 2.5 - phase)), 3);
        (mesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 3 + pulse * 7;
        halo.scale.setScalar(0.14 + pulse * 0.13);
        (halo.material as THREE.SpriteMaterial).opacity = 0.22 + pulse * 0.65;
      }
    },
    dispose() { texture?.dispose(); },
  };
}
