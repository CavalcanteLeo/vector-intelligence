import * as THREE from "three";

export function brainPoint(side: number, theta: number, phi: number, depth = 1) {
  const fold = 1 + 0.065 * Math.sin(theta * 7 + Math.sin(phi * 3)) * Math.sin(phi * 6);
  return new THREE.Vector3(
    side * 0.225 + Math.sin(phi) * Math.cos(theta) * 0.285 * fold * depth,
    0.585 + Math.cos(phi) * 0.255 * fold * depth,
    Math.sin(phi) * Math.sin(theta) * 0.405 * fold * depth,
  );
}

export function addBrainHemispheres(group: THREE.Group) {
  for (const side of [-1, 1]) {
    const geometry = new THREE.SphereGeometry(1, 96, 64);
    const positions = geometry.getAttribute("position");
    for (let index = 0; index < positions.count; index++) {
      const theta = Math.atan2(positions.getZ(index), positions.getX(index));
      const phi = Math.acos(THREE.MathUtils.clamp(positions.getY(index), -1, 1));
      const point = brainPoint(side, theta, phi, 0.975);
      positions.setXYZ(index, point.x, point.y, point.z);
    }
    geometry.computeVertexNormals();
    const material = new THREE.MeshPhysicalMaterial({
      color: 0x031838, emissive: 0x001b57, emissiveIntensity: 0.45,
      metalness: 0.1, roughness: 0.5, clearcoat: 0.25,
    });
    const hemisphere = new THREE.Mesh(geometry, material);
    hemisphere.name = side < 0 ? "LeftBrainHemisphere" : "RightBrainHemisphere";
    group.add(hemisphere);
  }
}
