import * as THREE from "three";

export function createEarPieces(model: THREE.Object3D) {
  const head = model.getObjectByName("HeadRig");
  if (!head) return;
  const shell = new THREE.MeshStandardMaterial({ color: 0x182334, metalness: 0.55, roughness: 0.33 });
  const silver = new THREE.MeshStandardMaterial({ color: 0xc4d0df, metalness: 0.55, roughness: 0.26 });
  const light = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.03, 1.4, 3), toneMapped: false });
  for (const side of [-1, 1]) {
    const ear = new THREE.Group();
    ear.position.set(side * 0.8, 0.55, 0);
    ear.rotation.z = side * Math.PI / 2;
    const housing = new THREE.Mesh(new THREE.LatheGeometry([new THREE.Vector2(0, -0.075), new THREE.Vector2(0.19, -0.075), new THREE.Vector2(0.22, -0.05), new THREE.Vector2(0.23, 0.03), new THREE.Vector2(0.21, 0.07), new THREE.Vector2(0, 0.07)], 64), silver);
    const inset = new THREE.Mesh(new THREE.CylinderGeometry(0.195, 0.195, 0.015, 64), shell);
    inset.position.y = -0.08;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.171, 0.008, 12, 64), light);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.091;
    ear.add(housing, inset, ring);
    head.add(ear);
  }
}
