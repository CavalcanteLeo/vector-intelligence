import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { createNeuralNetwork } from "./neural-network";
import { createEarPieces } from "./ear-pieces";
import { configureMaterials, createNeckJoint } from "./model-materials";
import { createPostProcessing } from "./post-processing";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";

export async function startMascotScene(element: HTMLElement, onReady: () => void) {
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.domElement.className = "absolute inset-0 h-full w-full touch-none cursor-grab active:cursor-grabbing";
  renderer.domElement.setAttribute("aria-hidden", "true");
  element.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room);
  scene.environment = environment.texture;
  scene.environmentIntensity = 0.35;
  room.dispose();
  pmrem.dispose();
  scene.add(new THREE.HemisphereLight(0xeaf5ff, 0x8899bb, 0.7));
  const key = new THREE.DirectionalLight(0xffffff, 1.5);
  key.position.set(-3, 4, 5);
  scene.add(key);
  const rim = new THREE.DirectionalLight(0x6daaff, 0.8);
  rim.position.set(3, 2, -3);
  scene.add(rim);
  const camera = new THREE.PerspectiveCamera(33, 1, 0.1, 100);
  camera.position.z = 4.1;
  const composer = createPostProcessing(renderer, scene, camera);

  const model = (await new GLTFLoader().loadAsync("/assets/models/vector-intelligence-mascot-preview.glb")).scene;
  configureMaterials(model);
  createNeckJoint(model);
  createEarPieces(model);
  scene.add(model);
  const neuralNetwork = createNeuralNetwork(model.getObjectByName("HeadRig") ?? model);
  const head = model.getObjectByName("HeadRig");
  const body = model.getObjectByName("BodyRig");

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const cursor = { x: 0, y: 0 };
  const drag = { active: false, lastX: 0, angle: 0 };
  const clock = new THREE.Clock();
  let frame = 0;
  let visible = false;

  function resize() {
    const { width, height } = element.getBoundingClientRect();
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    composer.setSize(width, height);
    composer.render();
  }
  function onMove(event: PointerEvent) {
    if (drag.active) {
      drag.angle += (event.clientX - drag.lastX) * 0.008;
      drag.lastX = event.clientX;
      return;
    }
    cursor.x = THREE.MathUtils.clamp((event.clientX / window.innerWidth - 0.5) * 2, -1, 1);
    cursor.y = THREE.MathUtils.clamp((event.clientY / window.innerHeight - 0.5) * 2, -1, 1);
  }
  function onDown(event: PointerEvent) {
    drag.active = true;
    drag.lastX = event.clientX;
    renderer.domElement.setPointerCapture(event.pointerId);
  }
  function onUp(event: PointerEvent) {
    drag.active = false;
    if (renderer.domElement.hasPointerCapture(event.pointerId)) renderer.domElement.releasePointerCapture(event.pointerId);
  }
  function animate() {
    if (!visible) return;
    const delta = Math.min(clock.getDelta(), 0.05);
    const ease = 1 - Math.exp(-delta * 4.5);
    model.rotation.y = THREE.MathUtils.lerp(model.rotation.y, drag.angle, ease);
    if (head) {
      head.rotation.y = THREE.MathUtils.lerp(head.rotation.y, reducedMotion.matches ? 0 : cursor.x * 0.17, ease);
      head.rotation.x = THREE.MathUtils.lerp(head.rotation.x, reducedMotion.matches ? 0 : -cursor.y * 0.07, ease);
    }
    if (body) body.rotation.y = THREE.MathUtils.lerp(body.rotation.y, reducedMotion.matches ? 0 : cursor.x * 0.025, ease * 0.55);
    model.position.y = reducedMotion.matches ? 0 : Math.sin(clock.elapsedTime * 1.1) * 0.012;
    neuralNetwork.update(reducedMotion.matches ? 0 : delta);
    composer.render();
    if (!reducedMotion.matches) frame = requestAnimationFrame(animate);
  }
  const observer = new IntersectionObserver(([entry]) => {
    visible = entry.isIntersecting;
    cancelAnimationFrame(frame);
    if (visible) { clock.getDelta(); frame = requestAnimationFrame(animate); }
  });
  observer.observe(element);
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(element);
  window.addEventListener("pointermove", onMove, { passive: true });
  renderer.domElement.addEventListener("pointerdown", onDown);
  renderer.domElement.addEventListener("pointerup", onUp);
  renderer.domElement.addEventListener("pointercancel", onUp);
  resize();
  onReady();

  return () => {
    visible = false;
    cancelAnimationFrame(frame);
    observer.disconnect();
    resizeObserver.disconnect();
    window.removeEventListener("pointermove", onMove);
    renderer.domElement.removeEventListener("pointerdown", onDown);
    renderer.domElement.removeEventListener("pointerup", onUp);
    renderer.domElement.removeEventListener("pointercancel", onUp);
    model.traverse((object) => {
      if (!(object instanceof THREE.Mesh)) return;
      object.geometry.dispose();
      const materials = Array.isArray(object.material) ? object.material : [object.material];
      materials.forEach((material) => material.dispose());
    });
    composer.passes.forEach((pass) => pass.dispose());
    composer.dispose();
    renderer.dispose();
    environment.dispose();
    renderer.domElement.remove();
  };
}
