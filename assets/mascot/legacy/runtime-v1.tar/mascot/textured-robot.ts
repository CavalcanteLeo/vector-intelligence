import * as THREE from "three";

const imageSize = 1254;
const modelSize = 3.45;

function glowTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 64;
  const context = canvas.getContext("2d")!;
  const gradient = context.createRadialGradient(32, 32, 2, 32, 32, 32);
  gradient.addColorStop(0, "rgba(120,235,255,1)");
  gradient.addColorStop(.22, "rgba(52,190,255,.8)");
  gradient.addColorStop(1, "rgba(52,190,255,0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

function curvedLayer(texture: THREE.Texture, imageTop: number, imageBottom: number) {
  const height = modelSize * (imageBottom - imageTop);
  const geometry = new THREE.PlaneGeometry(modelSize, height, 32, 20);
  const position = geometry.getAttribute("position");
  const uv = geometry.getAttribute("uv");

  for (let index = 0; index < position.count; index++) {
    const x = position.getX(index) / (modelSize / 2);
    position.setZ(index, .13 * (1 - x * x));
    uv.setY(index, 1 - imageBottom + uv.getY(index) * (imageBottom - imageTop));
  }
  geometry.computeVertexNormals();

  const base = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ map: texture, transparent: true, alphaTest: .01, depthWrite: false, side: THREE.DoubleSide }));
  const lightMaterial = new THREE.ShaderMaterial({
    uniforms: { map: { value: texture }, time: { value: 0 }, intensity: { value: 1 } },
    vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position + vec3(0., 0., .008), 1.); }`,
    fragmentShader: `
      uniform sampler2D map;
      uniform float time;
      uniform float intensity;
      varying vec2 vUv;
      void main() {
        vec4 source = texture2D(map, vUv);
        float blue = smoothstep(.18, .52, source.b - source.r);
        float luminous = smoothstep(.28, .78, source.g);
        float mask = blue * luminous * source.a;
        float wave = .48 + .52 * sin(time * 2.8 + vUv.x * 14. - vUv.y * 23.);
        float flash = pow(max(0., sin(time * 1.9 + vUv.x * 19. + vUv.y * 11.)), 16.);
        vec3 color = vec3(.04, .6, 1.) * (wave * .55 + flash * .6) * intensity;
        gl_FragColor = vec4(color, mask * .5);
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const lights = new THREE.Mesh(geometry, lightMaterial);
  lights.renderOrder = 2;
  const group = new THREE.Group();
  group.add(base, lights);
  return { group, lightMaterial };
}

export function createTexturedRobot(texture: THREE.Texture) {
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;

  const root = new THREE.Group();
  const body = curvedLayer(texture, .72, 1);
  const head = curvedLayer(texture, 0, .77);
  const neckY = -modelSize * (.72 - .5);

  body.group.position.y = -modelSize * ((.72 + 1) / 2 - .5);
  head.group.position.y = -modelSize * ((0 + .77) / 2 - .5) - neckY;
  const headPivot = new THREE.Group();
  headPivot.position.y = neckY;
  headPivot.position.z = .025;
  headPivot.add(head.group);
  root.add(body.group, headPivot);

  const points = [
    [522, 167], [596, 181], [674, 130], [844, 238],
    [930, 340], [386, 296], [427, 379], [928, 441],
  ];
  const haloMap = glowTexture();
  const nodes = points.map(([px, py], index) => {
    const light = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloMap, transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false }));
    light.position.set((px / imageSize - .5) * modelSize, (.5 - py / imageSize) * modelSize - neckY, .22);
    headPivot.add(light);
    return { light, index };
  });

  function pulse(time: number, reducedMotion: boolean) {
    head.lightMaterial.uniforms.time.value = time;
    body.lightMaterial.uniforms.time.value = time + .7;
    head.lightMaterial.uniforms.intensity.value = reducedMotion ? .38 : 1;
    body.lightMaterial.uniforms.intensity.value = reducedMotion ? .3 : .72;
    nodes.forEach(({ light, index }) => {
      const wave = reducedMotion ? .4 : (Math.sin(time * 2.6 - index * .65) + 1) / 2;
      (light.material as THREE.SpriteMaterial).opacity = .08 + wave * .2;
      light.scale.setScalar(.06 + wave * .08);
    });
  }

  return { root, headPivot, body: body.group, pulse };
}
